def plus(a, b):
  return a + b

def minus(a, b):
  return a - b

def times(a, b):
  return a * b

def division(a, b):
  return a / b

def remainder(a, b):
  return a % b

def negation(a, b):
  return -a

def power(a, b):
  return a ** b